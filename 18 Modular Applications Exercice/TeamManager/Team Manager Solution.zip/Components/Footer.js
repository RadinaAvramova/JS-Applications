import { html } from '../node_modules/lit-html/lit-html.js'

const Footer = () => html`
    <footer id="footer">
        SoftUni &copy; 2014-2021
    </footer>`

export { Footer }