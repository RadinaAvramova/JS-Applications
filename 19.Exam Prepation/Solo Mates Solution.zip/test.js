//app.js
//nav
    //page
//crud
    //api
//authentification
    //login
    //register
    //logout

//views
    //dom vizualization
    //logic for inserting data into dom and adding handlers



//search
//pagination
//modal
//sub collection - example contents
//likes/rating
//profile


