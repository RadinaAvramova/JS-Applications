export class UserReadableError extends Error {
    constructor(message) {
        super(message)
    }
}